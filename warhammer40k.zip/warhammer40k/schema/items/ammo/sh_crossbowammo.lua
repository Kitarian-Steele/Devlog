ITEM.name = "Crossbow Bolts"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "XBowBolt" -- type of the ammo
ITEM.ammoAmount = 5 -- amount of the ammo
ITEM.description = "A Bundle of %s Crossbow Bolts"

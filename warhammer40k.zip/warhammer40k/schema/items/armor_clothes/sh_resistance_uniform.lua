
ITEM.name = "Resistance Uniform"
ITEM.description = "A resistance uniform with a symbol on the sleeve."
ITEM.category = "Clothing"
ITEM.flag = "v"
ITEM.maxArmor = 50

ITEM.replacements = {
	{"group01", "group03"},
	{"group02", "group03"},
	{"group03m", "group03"},
}

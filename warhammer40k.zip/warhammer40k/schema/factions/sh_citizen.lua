FACTION.name = "Brother Initiates"
FACTION.description = "A regular human citizen enslaved by the Universal Union."
FACTION.color = Color(150, 125, 100, 255)
FACTION.isDefault = true
FACTION.isGloballyRecognized = true

function FACTION:OnSpawn(client)
  print("Player faction:", client:GetCharacter():GetFaction())
    client:SetHealth(700)
    client:SetMaxHealth(700)
    client:SetArmor(1000)
    client:SetMaxArmor(1000)

    client:SetRunSpeed(300)
    client:SetWalkSpeed(150)
end

FACTION_CITIZEN = FACTION.index

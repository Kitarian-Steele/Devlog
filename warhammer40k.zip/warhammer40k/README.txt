
# Warhammer 40K
A Warhammer 40K Roleplay schema for [Helix](https://github.com/nebulouscloud/helix).
